def count_word(input_string):
    count = len(input_string.split())
    return count

